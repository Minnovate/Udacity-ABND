package com.example.android.miwok;

/**
 * Created by gamelord on 6/30/16.
 */
public class Word {
    /** Default/Miwok translation for the word */
    private String mDefaultTranslation;
    private String mMiwokTranslation;
    private int mImagesResourceID;
    public Word(String defaultTranslation, String miwokTranslation, int ImagesResourceID ) {
        mDefaultTranslation = defaultTranslation;
        mMiwokTranslation = miwokTranslation;
        mImagesResourceID = ImagesResourceID;
    }
    public Word(String defaultTranslation, String miwokTranslation) {
        mDefaultTranslation = defaultTranslation;
        mMiwokTranslation = miwokTranslation;
    }
    /** Get the default translation of the word */
    public String getDefaultTranslation() {
        return mDefaultTranslation;
    }
    public String getMiwokTranslation(){return mMiwokTranslation;}
    public int getImageResourceID(){return mImagesResourceID; }
}
